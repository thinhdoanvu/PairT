#ifndef VERSION_GIT_H
#define VERSION_GIT_H
#define VERSION_GIT "v2.26.0"
#endif /* VERSION_GIT_H */
